from django.contrib import admin
from .models import Data,images,profile,Massage
# Register your models here.
admin.site.register(profile),
admin.site.register(Data),
admin.site.register(images),
admin.site.register(Massage),
